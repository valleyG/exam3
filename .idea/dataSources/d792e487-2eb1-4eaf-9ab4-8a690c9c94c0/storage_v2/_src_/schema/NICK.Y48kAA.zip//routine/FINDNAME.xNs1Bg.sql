CREATE PROCEDURE findName (studnetno IN VARCHAR2, studnetname OUT VARCHAR2)
AS
BEGIN
-- routine body goes here, e.g.
-- DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
SELECT sname INTO studnetname from STUDENT WHERE sno = studnetno;
END;
/

