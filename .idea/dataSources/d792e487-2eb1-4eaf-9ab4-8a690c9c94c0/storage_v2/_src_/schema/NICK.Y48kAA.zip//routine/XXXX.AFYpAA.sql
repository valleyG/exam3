CREATE PROCEDURE xxxx (xxx OUT sys_refcursor)
BEGIN
-- routine body goes here, e.g.
-- DBMS_OUTPUT.PUT_LINE('Navicat for Oracle');
open xxx for select * from STUDENT;
END;
/

